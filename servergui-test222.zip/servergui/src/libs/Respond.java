/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libs;

/**
 *
 * @author black horse
 */
public class Respond {

    public static final String SUCCESS = "success";
    public static final String FAILURE = "failure";
}

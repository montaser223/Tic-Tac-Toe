package guidemo2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.text.Font;

public class FXMLScreenTwo extends AnchorPane {

    protected final GridPane GridOfImageAndForm;
    protected final ColumnConstraints columnConstraints;
    protected final ColumnConstraints columnConstraints0;
    protected final RowConstraints rowConstraints;
    protected final ImageView SignUpImg;
    protected final AnchorPane SignUpFormPanel;
    protected final Label FirstName2;
    protected final TextField userText2;
    protected final Label usrName2;
    protected final Label label;
    protected final TextField FirstText2;
    protected final Label LastName2;
    protected final TextField LastText2;
    protected final Label pass2;
    protected final PasswordField passText2;
    protected final Button signupBtn2;
    protected final Button backBtn2;

    public FXMLScreenTwo() {

        GridOfImageAndForm = new GridPane();
        columnConstraints = new ColumnConstraints();
        columnConstraints0 = new ColumnConstraints();
        rowConstraints = new RowConstraints();
        SignUpImg = new ImageView();
        SignUpFormPanel = new AnchorPane();
        FirstName2 = new Label();
        userText2 = new TextField();
        usrName2 = new Label();
        label = new Label();
        FirstText2 = new TextField();
        LastName2 = new Label();
        LastText2 = new TextField();
        pass2 = new Label();
        passText2 = new PasswordField();
        signupBtn2 = new Button();
        backBtn2 = new Button();

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(540.0);
        setPrefWidth(642.0);

        GridOfImageAndForm.setPrefHeight(540.0);
        GridOfImageAndForm.setPrefWidth(642.0);
        GridOfImageAndForm.setStyle("-fx-background-color: linear-gradient(to right, #5c258d, #4389a2);;");

        columnConstraints.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints.setMinWidth(10.0);
        columnConstraints.setPrefWidth(100.0);

        columnConstraints0.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints0.setMinWidth(10.0);
        columnConstraints0.setPrefWidth(100.0);

        rowConstraints.setMinHeight(10.0);
        rowConstraints.setPrefHeight(30.0);
        rowConstraints.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        SignUpImg.setFitHeight(538.0);
        SignUpImg.setFitWidth(321.0);
        SignUpImg.setPickOnBounds(true);
        //SignUpImg.setImage(new Image(getClass().getResource("../../../Project/Img/registration-form-login-user-interface-man-stands-front-inputted-secure-data-which-is-displayed-big-screen-mobile-phone-isometric-flat-illustration-ui-banner-app_198695-66.jpg").toExternalForm()));
        try {
            FileInputStream stream = new FileInputStream("F:\\ITI\\Java\\Project\\Img\\registration.jpg");
            Image image = new Image(stream);
            SignUpImg.setImage(image);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLScreenOne.class.getName()).log(Level.SEVERE, null, ex);
        }
        GridPane.setColumnIndex(SignUpFormPanel, 1);
        SignUpFormPanel.setPrefHeight(200.0);
        SignUpFormPanel.setPrefWidth(200.0);

        FirstName2.setLayoutX(4.0);
        FirstName2.setLayoutY(181.0);
        FirstName2.setPrefHeight(51.0);
        FirstName2.setPrefWidth(77.0);
        FirstName2.setText("First Name");
        FirstName2.setTextFill(javafx.scene.paint.Color.valueOf("#fffefe"));
        FirstName2.setFont(new Font("Javanese Text", 15.0));

        userText2.setLayoutX(94.0);
        userText2.setLayoutY(127.0);
        userText2.setPrefHeight(34.0);
        userText2.setPrefWidth(213.0);

        usrName2.setLayoutX(4.0);
        usrName2.setLayoutY(118.0);
        usrName2.setPrefHeight(51.0);
        usrName2.setPrefWidth(77.0);
        usrName2.setText("User Name");
        usrName2.setTextFill(javafx.scene.paint.Color.valueOf("#fffefe"));
        usrName2.setFont(new Font("Javanese Text", 15.0));

        label.setAlignment(javafx.geometry.Pos.CENTER);
        label.setLayoutX(23.0);
        label.setLayoutY(46.0);
        label.setPrefHeight(51.0);
        label.setPrefWidth(287.0);
        label.setText("SIGN UP");
        label.setTextFill(javafx.scene.paint.Color.WHITE);
        label.setFont(new Font("Javanese Text", 24.0));

        FirstText2.setLayoutX(94.0);
        FirstText2.setLayoutY(190.0);
        FirstText2.setPrefHeight(34.0);
        FirstText2.setPrefWidth(213.0);

        LastName2.setLayoutX(4.0);
        LastName2.setLayoutY(245.0);
        LastName2.setPrefHeight(51.0);
        LastName2.setPrefWidth(77.0);
        LastName2.setText("Last Name");
        LastName2.setTextFill(javafx.scene.paint.Color.valueOf("#fffefe"));
        LastName2.setFont(new Font("Javanese Text", 15.0));

        LastText2.setLayoutX(94.0);
        LastText2.setLayoutY(254.0);
        LastText2.setPrefHeight(34.0);
        LastText2.setPrefWidth(213.0);

        pass2.setLayoutX(4.0);
        pass2.setLayoutY(307.0);
        pass2.setPrefHeight(51.0);
        pass2.setPrefWidth(77.0);
        pass2.setText("Password");
        pass2.setTextFill(javafx.scene.paint.Color.valueOf("#fffefe"));
        pass2.setFont(new Font("Javanese Text", 15.0));

        passText2.setLayoutX(92.0);
        passText2.setLayoutY(311.0);
        passText2.setPrefHeight(34.0);
        passText2.setPrefWidth(213.0);

        signupBtn2.setLayoutX(92.0);
        signupBtn2.setLayoutY(383.0);
        signupBtn2.setMnemonicParsing(false);
        signupBtn2.setPrefHeight(53.0);
        signupBtn2.setPrefWidth(173.0);
        signupBtn2.setStyle("-fx-background-color: linear-gradient(to right, #283048, #859398);;");
        signupBtn2.setText("sign up");
        signupBtn2.setTextFill(javafx.scene.paint.Color.WHITE);
        signupBtn2.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        backBtn2.setLayoutX(94.0);
        backBtn2.setLayoutY(452.0);
        backBtn2.setMnemonicParsing(false);
        backBtn2.setPrefHeight(53.0);
        backBtn2.setPrefWidth(173.0);
        backBtn2.setText("Back");
        backBtn2.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        GridOfImageAndForm.getColumnConstraints().add(columnConstraints);
        GridOfImageAndForm.getColumnConstraints().add(columnConstraints0);
        GridOfImageAndForm.getRowConstraints().add(rowConstraints);
        GridOfImageAndForm.getChildren().add(SignUpImg);
        SignUpFormPanel.getChildren().add(FirstName2);
        SignUpFormPanel.getChildren().add(userText2);
        SignUpFormPanel.getChildren().add(usrName2);
        SignUpFormPanel.getChildren().add(label);
        SignUpFormPanel.getChildren().add(FirstText2);
        SignUpFormPanel.getChildren().add(LastName2);
        SignUpFormPanel.getChildren().add(LastText2);
        SignUpFormPanel.getChildren().add(pass2);
        SignUpFormPanel.getChildren().add(passText2);
        SignUpFormPanel.getChildren().add(signupBtn2);
        SignUpFormPanel.getChildren().add(backBtn2);
        GridOfImageAndForm.getChildren().add(SignUpFormPanel);
        getChildren().add(GridOfImageAndForm);

    }
}

package guidemo2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;

public class FXMLScreenOnev2 extends AnchorPane {

    protected final ImageView LoginImg;
    protected final Label LoginLabel;
    protected final Label usrName1;
    protected final TextField userText1;
    protected final Label pass1;
    protected final TextField passText1;
    protected final Button logInBtn1;
    protected final Button signupBtn1;

    public FXMLScreenOnev2() {

        LoginImg = new ImageView();
        LoginLabel = new Label();
        usrName1 = new Label();
        userText1 = new TextField();
        pass1 = new Label();
        passText1 = new PasswordField();
        logInBtn1 = new Button();
        signupBtn1 = new Button();

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(540.0);
        setPrefWidth(642.0);
        setStyle("-fx-background-color: linear-gradient(to right, #5c258d, #4389a2);;");

        LoginImg.setFitHeight(540.0);
        LoginImg.setFitWidth(307.0);
        LoginImg.setPickOnBounds(true);
//        LoginImg.setImage(new Image(getClass().getResource("../../../Project/Img/login.jpg").toExternalForm()));
        try {
            FileInputStream stream = new FileInputStream("F:\\ITI\\Java\\Project\\Img\\login.jpg");
            Image image = new Image(stream);
            LoginImg.setImage(image);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLScreenOne.class.getName()).log(Level.SEVERE, null, ex);
        }

        LoginLabel.setAlignment(javafx.geometry.Pos.CENTER);
        LoginLabel.setLayoutX(387.0);
        LoginLabel.setLayoutY(78.0);
        LoginLabel.setPrefHeight(17.0);
        LoginLabel.setPrefWidth(204.0);
        LoginLabel.setText("Login");
        LoginLabel.setTextFill(javafx.scene.paint.Color.WHITE);
        LoginLabel.setFont(new Font("Javanese Text", 24.0));

        usrName1.setLayoutX(315.0);
        usrName1.setLayoutY(164.0);
        usrName1.setPrefHeight(51.0);
        usrName1.setPrefWidth(77.0);
        usrName1.setText("User Name");
        usrName1.setTextFill(javafx.scene.paint.Color.valueOf("#fffefe"));
        usrName1.setFont(new Font("Javanese Text", 15.0));

        userText1.setLayoutX(411.0);
        userText1.setLayoutY(177.0);
        userText1.setPrefHeight(34.0);
        userText1.setPrefWidth(213.0);

        pass1.setLayoutX(315.0);
        pass1.setLayoutY(256.0);
        pass1.setPrefHeight(51.0);
        pass1.setPrefWidth(77.0);
        pass1.setText("Password");
        pass1.setTextFill(javafx.scene.paint.Color.valueOf("#fffefe"));
        pass1.setFont(new Font("Javanese Text", 15.0));

        passText1.setAccessibleRole(javafx.scene.AccessibleRole.PASSWORD_FIELD);
        passText1.setLayoutX(411.0);
        passText1.setLayoutY(264.0);
        passText1.setPrefHeight(34.0);
        passText1.setPrefWidth(213.0);

        logInBtn1.setLayoutX(411.0);
        logInBtn1.setLayoutY(361.0);
        logInBtn1.setMnemonicParsing(false);
        logInBtn1.setPrefHeight(53.0);
        logInBtn1.setPrefWidth(213.0);
        logInBtn1.setStyle("-fx-background-color: linear-gradient(to right, #283048, #859398);;");
        logInBtn1.setText("Login");
        logInBtn1.setTextFill(javafx.scene.paint.Color.WHITE);
        logInBtn1.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        signupBtn1.setLayoutX(410.0);
        signupBtn1.setLayoutY(432.0);
        signupBtn1.setMnemonicParsing(false);
        signupBtn1.setPrefHeight(53.0);
        signupBtn1.setPrefWidth(213.0);
        signupBtn1.setText("Sign up");
        signupBtn1.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        getChildren().add(LoginImg);
        getChildren().add(LoginLabel);
        getChildren().add(usrName1);
        getChildren().add(userText1);
        getChildren().add(pass1);
        getChildren().add(passText1);
        getChildren().add(logInBtn1);
        getChildren().add(signupBtn1);

    }
}

package guidemo2;

import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;

public class FXMLServer extends AnchorPane {

    protected final ImageView serverImg;
    protected final Button serverBtn1;
    protected final Button serverBtn2;

    public FXMLServer() {

        serverImg = new ImageView();
        serverBtn1 = new Button();
        serverBtn2 = new Button();

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(540.0);
        setPrefWidth(642.0);
        setStyle("-fx-background-color: linear-gradient(to right, #5c258d, #4389a2);;");

        serverImg.setFitHeight(540.0);
        serverImg.setFitWidth(377.0);
        serverImg.setPickOnBounds(true);
        serverImg.setImage(new Image(getClass().getResource("../../../Project/Img/server.jpg").toExternalForm()));

        serverBtn1.setLayoutX(389.0);
        serverBtn1.setLayoutY(192.0);
        serverBtn1.setMnemonicParsing(false);
        serverBtn1.setPrefHeight(53.0);
        serverBtn1.setPrefWidth(213.0);
        serverBtn1.setStyle("-fx-background-color: linear-gradient(to right, #283048, #859398);;");
        serverBtn1.setText("Start");
        serverBtn1.setTextFill(javafx.scene.paint.Color.WHITE);
        serverBtn1.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        serverBtn2.setLayoutX(395.0);
        serverBtn2.setLayoutY(297.0);
        serverBtn2.setMnemonicParsing(false);
        serverBtn2.setPrefHeight(53.0);
        serverBtn2.setPrefWidth(213.0);
        serverBtn2.setText("Stop");
        serverBtn2.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        getChildren().add(serverImg);
        getChildren().add(serverBtn1);
        getChildren().add(serverBtn2);

    }
}

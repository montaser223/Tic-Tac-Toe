package guidemo2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;

public class FXMLScreenFour extends AnchorPane {

    protected final ImageView TableImg;
    protected final TableView PlayerTable;
    protected final TableColumn PlayerName;
    protected final TableColumn Score;
    protected final TableColumn Status;
    protected final Label TableLabel;
    protected final Button button;
    protected final Button button0;

    public FXMLScreenFour() {

        TableImg = new ImageView();
        PlayerTable = new TableView();
        PlayerName = new TableColumn();
        Score = new TableColumn();
        Status = new TableColumn();
        TableLabel = new Label();
        button = new Button();
        button0 = new Button();

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(540.0);
        setPrefWidth(642.0);
        setStyle("-fx-background-color: linear-gradient(to right, #0f0c29, #302b63, #24243e);");

        TableImg.setFitHeight(540.0);
        TableImg.setFitWidth(642.0);
        TableImg.setPickOnBounds(true);
//        TableImg.setImage(new Image(getClass().getResource("../../../Project/Img/image.jpg").toExternalForm()));
        try {
            FileInputStream stream = new FileInputStream("F:\\ITI\\Java\\Project\\Img\\image.jpg");
            Image image = new Image(stream);
            TableImg.setImage(image);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLScreenOne.class.getName()).log(Level.SEVERE, null, ex);
        }

        PlayerTable.setLayoutX(89.0);
        PlayerTable.setLayoutY(109.0);
        PlayerTable.setPrefHeight(287.0);
        PlayerTable.setPrefWidth(480.0);

        PlayerName.setPrefWidth(178.0);
        PlayerName.setText("Player Name");

        Score.setPrefWidth(132.0);
        Score.setText("Score");

        Status.setPrefWidth(169.0);
        Status.setText("Status");

        TableLabel.setAlignment(javafx.geometry.Pos.CENTER);
        TableLabel.setLayoutX(167.0);
        TableLabel.setLayoutY(28.0);
        TableLabel.setPrefHeight(46.0);
        TableLabel.setPrefWidth(309.0);
        TableLabel.setText("Player List");
        TableLabel.setTextFill(javafx.scene.paint.Color.valueOf("#fffbfb"));
        TableLabel.setFont(new Font("Javanese Text", 24.0));

        button.setAlignment(javafx.geometry.Pos.CENTER);
        button.setLayoutX(379.0);
        button.setLayoutY(456.0);
        button.setMnemonicParsing(false);
        button.setPrefHeight(44.0);
        button.setPrefWidth(173.0);
        button.setStyle("-fx-background-color: linear-gradient(to right, #000428, #004e92);;");
        button.setText("Play");
        button.setTextFill(javafx.scene.paint.Color.valueOf("#fffdfd"));
        button.setFont(new Font("Lucida Calligraphy Italic", 20.0));

        button0.setAlignment(javafx.geometry.Pos.CENTER);
        button0.setLayoutX(98.0);
        button0.setLayoutY(456.0);
        button0.setMnemonicParsing(false);
        button0.setPrefHeight(44.0);
        button0.setPrefWidth(173.0);
        button0.setStyle("-fx-background-color: linear-gradient(to right, #000428, #004e92);;");
        button0.setText("Back");
        button0.setTextFill(javafx.scene.paint.Color.valueOf("#fffdfd"));
        button0.setFont(new Font("Lucida Calligraphy Italic", 20.0));

        getChildren().add(TableImg);
        PlayerTable.getColumns().add(PlayerName);
        PlayerTable.getColumns().add(Score);
        PlayerTable.getColumns().add(Status);
        getChildren().add(PlayerTable);
        getChildren().add(TableLabel);
        getChildren().add(button);
        getChildren().add(button0);

    }
}

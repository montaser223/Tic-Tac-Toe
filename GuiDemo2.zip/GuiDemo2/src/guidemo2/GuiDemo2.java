/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guidemo2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author hebaa
 */
public class GuiDemo2 extends Application {

    private Object imageView;
    
    @Override
    public void start(Stage stage) {
        try
        {
            Parent root = new FXMLServer();
            Scene scene = new Scene(root);

            try {
                //creating the image object
                InputStream stream = new FileInputStream("F:\\ITI\\Java\\Project\\Img\\xo.png");
                Image image = new Image(stream);
                //Creating the image view
                ImageView imageView = new ImageView();
                //Setting image to the image view
                stage.getIcons().add(image);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(GuiDemo2.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            stage.setScene(scene);
            stage.setResizable(true);
            stage.setTitle("Tic Tac Toe");
            stage.show();
        }
        catch(NullPointerException ex)
        {
            System.out.println("Error");
        }
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}

package guidemo2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class FXMLSingleMode extends AnchorPane {

    protected final ImageView GameImg;
    protected final Button exit;
    protected final Button recordGame;
    protected final Button bt1;
    protected final Button bt2;
    protected final Button bt3;
    protected final Button bt4;
    protected final Button bt5;
    protected final Button bt6;
    protected final Button bt7;
    protected final Button bt8;
    protected final Button bt9;
    protected final Label playerScore;
    protected final Label computerScore;
    protected final Label playerName;
    protected final Label computerName;
    protected final Label scoreSeperator;

    public FXMLSingleMode() {

        GameImg = new ImageView();
        exit = new Button();
        recordGame = new Button();
        bt1 = new Button();
        bt2 = new Button();
        bt3 = new Button();
        bt4 = new Button();
        bt5 = new Button();
        bt6 = new Button();
        bt7 = new Button();
        bt8 = new Button();
        bt9 = new Button();
        playerScore = new Label();
        computerScore = new Label();
        playerName = new Label();
        computerName = new Label();
        scoreSeperator = new Label();

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(540.0);
        setPrefWidth(642.0);
        setStyle("-fx-background-color: linear-gradient(to right, #0f0c29, #302b63, #24243e);");

        GameImg.setFitHeight(540.0);
        GameImg.setFitWidth(642.0);
        GameImg.setPickOnBounds(true);
//        GameImg.setImage(new Image(getClass().getResource("../../../Project/Img/image123.jpg").toExternalForm()));
        try {
            FileInputStream stream = new FileInputStream("F:\\ITI\\Java\\Project\\Img\\image.jpg");
            Image image = new Image(stream);
            GameImg.setImage(image);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLScreenOne.class.getName()).log(Level.SEVERE, null, ex);
        }

        exit.setAlignment(javafx.geometry.Pos.CENTER);
        exit.setLayoutX(331.0);
        exit.setLayoutY(456.0);
        exit.setMnemonicParsing(false);
        exit.setPrefHeight(46.0);
        exit.setPrefWidth(179.0);
        exit.setStyle("-fx-background-color: linear-gradient(to right, #616161, #9bc5c3);;");
        exit.setText("Exit");
        exit.setTextFill(javafx.scene.paint.Color.WHITE);
        exit.setFont(new Font("Lucida Calligraphy Italic", 20.0));

        recordGame.setAlignment(javafx.geometry.Pos.CENTER);
        recordGame.setLayoutX(93.0);
        recordGame.setLayoutY(456.0);
        recordGame.setMnemonicParsing(false);
        recordGame.setPrefHeight(46.0);
        recordGame.setPrefWidth(179.0);
        recordGame.setStyle("-fx-background-color: linear-gradient(to right, #616161, #9bc5c3);;");
        recordGame.setText("Record Game");
        recordGame.setTextFill(javafx.scene.paint.Color.valueOf("#fffdfd"));
        recordGame.setFont(new Font("Lucida Calligraphy Italic", 20.0));

        bt1.setLayoutX(120.0);
        bt1.setLayoutY(102.0);
        bt1.setMnemonicParsing(false);
        bt1.setPrefHeight(89.0);
        bt1.setPrefWidth(95.0);
        bt1.setText("x");
        bt1.setFont(Font.font("Engravers MT", FontWeight.BOLD, 36));
        bt1.setStyle("-fx-background-color:#128dba");
        
        bt2.setText("o");
        bt2.setFont(Font.font("Engravers MT", FontWeight.BOLD, 36));
        bt2.setLayoutX(249.0);
        bt2.setLayoutY(100.0);
        bt2.setMnemonicParsing(false);
        bt2.setPrefHeight(89.0);
        bt2.setPrefWidth(95.0);

        bt3.setLayoutX(376.0);
        bt3.setLayoutY(100.0);
        bt3.setMnemonicParsing(false);
        bt3.setPrefHeight(89.0);
        bt3.setPrefWidth(95.0);

        bt4.setLayoutX(120.0);
        bt4.setLayoutY(215.0);
        bt4.setMnemonicParsing(false);
        bt4.setPrefHeight(89.0);
        bt4.setPrefWidth(95.0);

        bt5.setLayoutX(249.0);
        bt5.setLayoutY(215.0);
        bt5.setMnemonicParsing(false);
        bt5.setPrefHeight(89.0);
        bt5.setPrefWidth(95.0);

        bt6.setLayoutX(377.0);
        bt6.setLayoutY(215.0);
        bt6.setMnemonicParsing(false);
        bt6.setPrefHeight(89.0);
        bt6.setPrefWidth(95.0);

        bt7.setLayoutX(120.0);
        bt7.setLayoutY(331.0);
        bt7.setMnemonicParsing(false);
        bt7.setPrefHeight(89.0);
        bt7.setPrefWidth(95.0);

        bt8.setLayoutX(249.0);
        bt8.setLayoutY(334.0);
        bt8.setMnemonicParsing(false);
        bt8.setPrefHeight(89.0);
        bt8.setPrefWidth(95.0);

        bt9.setLayoutX(377.0);
        bt9.setLayoutY(336.0);
        bt9.setMnemonicParsing(false);
        bt9.setPrefHeight(89.0);
        bt9.setPrefWidth(95.0);

        playerName.setLayoutX(122.0);
        playerName.setLayoutY(5.0);
        playerName.setText("Player Name");
        playerName.setTextFill(javafx.scene.paint.Color.WHITE);
        playerName.setFont(Font.font("Javanese Text", FontWeight.BOLD, 20));

        computerName.setLayoutX(390.0);
        computerName.setLayoutY(5.0);
        computerName.setText("Computer");
        computerName.setTextFill(javafx.scene.paint.Color.WHITE);
        computerName.setFont(Font.font("Javanese Text", FontWeight.BOLD, 20));
        
        playerScore.setLayoutX(140.0);
        playerScore.setLayoutY(50.0);
        playerScore.setText("1");
        playerScore.setTextFill(javafx.scene.paint.Color.WHITE);
        playerScore.setFont(Font.font("Engravers MT", FontWeight.BOLD, 36));

        scoreSeperator.setLayoutX(300.0);
        scoreSeperator.setLayoutY(14.0);
        scoreSeperator.setPrefWidth(28.0);
        scoreSeperator.setText(":");
        scoreSeperator.setTextFill(javafx.scene.paint.Color.WHITE);
        scoreSeperator.setFont(Font.font("Engravers MT", FontWeight.BOLD, 36));

        computerScore.setLayoutX(410.0);
        computerScore.setLayoutY(50.0);
        computerScore.setText("0");
        computerScore.setFont(Font.font("Engravers MT", FontWeight.BOLD, 36));
        computerScore.setTextFill(javafx.scene.paint.Color.WHITE);

        getChildren().add(GameImg);
        getChildren().add(exit);
        getChildren().add(recordGame);
        getChildren().add(bt1);
        getChildren().add(bt2);
        getChildren().add(bt3);
        getChildren().add(bt4);
        getChildren().add(bt5);
        getChildren().add(bt6);
        getChildren().add(bt7);
        getChildren().add(bt8);
        getChildren().add(bt9);
        getChildren().add(playerScore);
        getChildren().add(computerScore);
        getChildren().add(playerName);
        getChildren().add(computerName);
        getChildren().add(scoreSeperator);

    }
}

package guidemo2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;

public class FXMLScreenOne extends AnchorPane {

    protected final ImageView imageView;
    protected final Label UserNameScreenOne;
    protected final Label PasswordScreenOne;
    protected final TextField PasswordTextScreenOne;
    protected final TextField UserTextScreenOne;
    protected final Button LoginBtn;
    protected final Button SignBtnScreenOne;
    InputStream stream;
    public FXMLScreenOne() {

        imageView = new ImageView();
        UserNameScreenOne = new Label();
        PasswordScreenOne = new Label();
        PasswordTextScreenOne = new TextField();
        UserTextScreenOne = new TextField();
        LoginBtn = new Button();
        SignBtnScreenOne = new Button();

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(428.0);
        setPrefWidth(642.0);
        setStyle("-fx-background-image: url('F:/ITI/Java/GuiDemo/src/guidemo/img1.jpg');; -fx-background-color: ;");

        imageView.setFitHeight(453.0);
        imageView.setFitWidth(641.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);

        try {
            stream = new FileInputStream("F:\\ITI\\Java\\GuiDemo\\src\\guidemo\\img1.jpg");
            Image image = new Image(stream);
            imageView.setImage(image);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLScreenOne.class.getName()).log(Level.SEVERE, null, ex);
        }

        UserNameScreenOne.setLayoutX(20.0);
        UserNameScreenOne.setLayoutY(142.0);
        UserNameScreenOne.setPrefHeight(33.0);
        UserNameScreenOne.setPrefWidth(118.0);
        UserNameScreenOne.setText("User Name");
        UserNameScreenOne.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        PasswordScreenOne.setLayoutX(15.0);
        PasswordScreenOne.setLayoutY(234.0);
        PasswordScreenOne.setPrefHeight(33.0);
        PasswordScreenOne.setPrefWidth(118.0);
        PasswordScreenOne.setText("Password");
        PasswordScreenOne.setFont(new Font("Lucida Calligraphy Italic", 20.0));

        PasswordTextScreenOne.setLayoutX(178.0);
        PasswordTextScreenOne.setLayoutY(233.0);
        PasswordTextScreenOne.setPrefHeight(33.0);
        PasswordTextScreenOne.setPrefWidth(291.0);

        UserTextScreenOne.setLayoutX(175.0);
        UserTextScreenOne.setLayoutY(139.0);
        UserTextScreenOne.setPrefHeight(33.0);
        UserTextScreenOne.setPrefWidth(291.0);

        LoginBtn.setLayoutX(266.0);
        LoginBtn.setLayoutY(303.0);
        LoginBtn.setMnemonicParsing(false);
        LoginBtn.setPrefHeight(39.0);
        LoginBtn.setPrefWidth(146.0);
        LoginBtn.setStyle("-fx-background-color: #FFA500;");
        LoginBtn.setText("LogIn");
        LoginBtn.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        SignBtnScreenOne.setLayoutX(264.0);
        SignBtnScreenOne.setLayoutY(358.0);
        SignBtnScreenOne.setMnemonicParsing(false);
        SignBtnScreenOne.setPrefHeight(39.0);
        SignBtnScreenOne.setPrefWidth(149.0);
        SignBtnScreenOne.setStyle("-fx-background-color: #87CEEB;");
        SignBtnScreenOne.setText("SignUp");
        SignBtnScreenOne.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        getChildren().add(imageView);
        getChildren().add(UserNameScreenOne);
        getChildren().add(PasswordScreenOne);
        getChildren().add(PasswordTextScreenOne);
        getChildren().add(UserTextScreenOne);
        getChildren().add(LoginBtn);
        getChildren().add(SignBtnScreenOne);

    }
  
}

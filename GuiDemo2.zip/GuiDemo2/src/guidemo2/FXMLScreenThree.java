package guidemo2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.text.Font;

public class FXMLScreenThree extends AnchorPane {

    protected final GridPane GridOfPlay;
    protected final ColumnConstraints columnConstraints;
    protected final RowConstraints rowConstraints;
    protected final AnchorPane PlayPanel;
    protected final ImageView PlayImg;
    protected final Label PlayLable;
    protected final Button singleBtn3;
    protected final Button multiBtn3;
    protected final Button logOutBtn3;

    public FXMLScreenThree() {

        GridOfPlay = new GridPane();
        columnConstraints = new ColumnConstraints();
        rowConstraints = new RowConstraints();
        PlayPanel = new AnchorPane();
        PlayImg = new ImageView();
        PlayLable = new Label();
        singleBtn3 = new Button();
        multiBtn3 = new Button();
        logOutBtn3 = new Button();

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(540.0);
        setPrefWidth(642.0);

        GridOfPlay.setPrefHeight(540.0);
        GridOfPlay.setPrefWidth(642.0);

        columnConstraints.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints.setMinWidth(10.0);
        columnConstraints.setPrefWidth(100.0);

        rowConstraints.setMinHeight(10.0);
        rowConstraints.setPrefHeight(30.0);
        rowConstraints.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        PlayPanel.setPrefHeight(200.0);
        PlayPanel.setPrefWidth(200.0);
        PlayPanel.setStyle("-fx-background-image: <?xml version='1.0' encoding='UTF-8'?><?import javafx.scene.control.Button?><?import javafx.scene.text.Font?><Button fx:id='signupBtn2' layoutX='226.0' layoutY='153.0' mnemonicParsing='false' prefHeight='53.0' prefWidth='173.0' style='-fx-background-color: linear-gradient(to right, #283048, #859398);;' text='Sign UP' textFill='WHITE' xmlns='http://javafx.com/javafx/8.0.171' xmlns:fx='http://javafx.com/fxml/1'>   <font>      <Font name='Lucida Calligraphy Italic' size='18.0' />   </font></Button>;");

        PlayImg.setFitHeight(540.0);
        PlayImg.setFitWidth(642.0);
        PlayImg.setPickOnBounds(true);
//        PlayImg.setImage(new Image(getClass().getResource("../../../Project/Img/rocket.jpg").toExternalForm()));
        try {
            FileInputStream stream = new FileInputStream("F:\\ITI\\Java\\Project\\Img\\rocket.jpg");
            Image image = new Image(stream);
            PlayImg.setImage(image);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLScreenOne.class.getName()).log(Level.SEVERE, null, ex);
        }

        PlayLable.setAlignment(javafx.geometry.Pos.CENTER);
        PlayLable.setLayoutX(145.0);
        PlayLable.setLayoutY(48.0);
        PlayLable.setPrefHeight(67.0);
        PlayLable.setPrefWidth(339.0);
        PlayLable.setText("Let's Play");
        PlayLable.setTextFill(javafx.scene.paint.Color.WHITE);
        PlayLable.setFont(new Font("Javanese Text", 36.0));

        singleBtn3.setLayoutX(226.0);
        singleBtn3.setLayoutY(153.0);
        singleBtn3.setMnemonicParsing(false);
        singleBtn3.setPrefHeight(53.0);
        singleBtn3.setPrefWidth(173.0);
        singleBtn3.setStyle("-fx-background-color: linear-gradient(to right, #283048, #859398);;");
        singleBtn3.setText("Signle Mode");
        singleBtn3.setTextFill(javafx.scene.paint.Color.WHITE);
        singleBtn3.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        multiBtn3.setLayoutX(226.0);
        multiBtn3.setLayoutY(244.0);
        multiBtn3.setMnemonicParsing(false);
        multiBtn3.setPrefHeight(53.0);
        multiBtn3.setPrefWidth(173.0);
        multiBtn3.setText("Multi Mode");
        multiBtn3.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        logOutBtn3.setLayoutX(226.0);
        logOutBtn3.setLayoutY(346.0);
        logOutBtn3.setMnemonicParsing(false);
        logOutBtn3.setPrefHeight(53.0);
        logOutBtn3.setPrefWidth(173.0);
        logOutBtn3.setStyle("-fx-background-color: linear-gradient(to right, #283048, #859398);;");
        logOutBtn3.setText("Logout");
        logOutBtn3.setTextFill(javafx.scene.paint.Color.WHITE);
        logOutBtn3.setFont(new Font("Lucida Calligraphy Italic", 18.0));

        GridOfPlay.getColumnConstraints().add(columnConstraints);
        GridOfPlay.getRowConstraints().add(rowConstraints);
        PlayPanel.getChildren().add(PlayImg);
        PlayPanel.getChildren().add(PlayLable);
        PlayPanel.getChildren().add(singleBtn3);
        PlayPanel.getChildren().add(multiBtn3);
        PlayPanel.getChildren().add(logOutBtn3);
        GridOfPlay.getChildren().add(PlayPanel);
        getChildren().add(GridOfPlay);

    }
}
